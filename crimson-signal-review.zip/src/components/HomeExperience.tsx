"use client";

import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import type { BusinessEvent } from "@/lib/types";
import { ConversationFlow } from "./ConversationFlow";

type Step = "select" | "conversation" | "brief";

function HomeConversationInner({
  events,
  onStepChange,
}: {
  events: BusinessEvent[];
  onStepChange: (step: Step) => void;
}) {
  const searchParams = useSearchParams();
  const eventSlug = searchParams.get("event") ?? undefined;

  return (
    <ConversationFlow
      events={events}
      initialEventSlug={eventSlug}
      basePath="/"
      variant="home"
      onStepChange={onStepChange}
    />
  );
}

export function HomeExperience({ events }: { events: BusinessEvent[] }) {
  const [step, setStep] = useState<Step>("select");

  return (
    <div
      className={`flex min-h-[calc(100dvh-3.5rem)] flex-col px-4 sm:px-6 ${
        step === "select" ? "justify-center py-8" : "justify-start py-10 md:py-14"
      }`}
    >
      <div className="mx-auto w-full max-w-3xl">
        <Suspense
          fallback={
            <div className="text-center">
              <h1 className="mb-6 text-2xl font-medium tracking-tight text-foreground md:text-3xl">
                What changed?
              </h1>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {events.map((event) => (
                  <div
                    key={event.slug}
                    className="h-[72px] animate-pulse rounded-lg border border-border bg-border-light/50"
                  />
                ))}
              </div>
            </div>
          }
        >
          <HomeConversationInner events={events} onStepChange={setStep} />
        </Suspense>
      </div>
    </div>
  );
}
