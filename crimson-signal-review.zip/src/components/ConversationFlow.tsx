"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import type { BusinessEvent, ConversationQuestion } from "@/lib/types";
import { generateExecutiveBrief } from "@/lib/brief";
import { ExecutiveBriefDisplay } from "./ExecutiveBriefDisplay";
import { CTAButton } from "./CTAButton";

type Step = "select" | "conversation" | "brief";

interface ConversationFlowProps {
  events: BusinessEvent[];
  initialEventSlug?: string;
  basePath?: string;
  variant?: "home" | "page";
  onStepChange?: (step: Step) => void;
}

export function ConversationFlow({
  events,
  initialEventSlug,
  basePath = "/brief",
  variant = "page",
  onStepChange,
}: ConversationFlowProps) {
  const router = useRouter();
  const isHome = variant === "home";
  const [step, setStep] = useState<Step>(initialEventSlug ? "conversation" : "select");
  const [selectedEvent, setSelectedEvent] = useState<BusinessEvent | null>(
    initialEventSlug ? events.find((e) => e.slug === initialEventSlug) ?? null : null
  );
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});

  const updatePath = useCallback(
    (eventSlug?: string) => {
      const path = eventSlug ? `${basePath}?event=${eventSlug}` : basePath;
      router.replace(path, { scroll: false });
    },
    [router, basePath]
  );

  const selectEvent = useCallback(
    (event: BusinessEvent) => {
      setSelectedEvent(event);
      setQuestionIndex(0);
      setAnswers({});
      setStep("conversation");
      onStepChange?.("conversation");
      updatePath(event.slug);
    },
    [updatePath, onStepChange]
  );

  const currentQuestion: ConversationQuestion | undefined =
    selectedEvent?.questions[questionIndex];

  const handleAnswer = (value: string | string[]) => {
    if (!currentQuestion) return;
    const updated = { ...answers, [currentQuestion.id]: value };
    setAnswers(updated);

    if (selectedEvent && questionIndex < selectedEvent.questions.length - 1) {
      setQuestionIndex(questionIndex + 1);
    } else {
      setStep("brief");
      onStepChange?.("brief");
    }
  };

  const handleMultiselectToggle = (option: string) => {
    if (!currentQuestion) return;
    const current = (answers[currentQuestion.id] as string[]) ?? [];
    const updated = current.includes(option)
      ? current.filter((o) => o !== option)
      : [...current, option];
    setAnswers({ ...answers, [currentQuestion.id]: updated });
  };

  const handleMultiselectContinue = () => {
    if (!currentQuestion) return;
    const current = (answers[currentQuestion.id] as string[]) ?? [];
    if (current.length === 0) return;
    handleAnswer(current);
  };

  const reset = () => {
    setStep("select");
    setSelectedEvent(null);
    setQuestionIndex(0);
    setAnswers({});
    onStepChange?.("select");
    updatePath();
  };

  if (step === "brief" && selectedEvent) {
    const brief = generateExecutiveBrief(selectedEvent, answers);
    return (
      <div className="animate-fade-in">
        <button
          onClick={reset}
          className="mb-6 text-sm text-muted-light transition-colors hover:text-foreground"
        >
          ← Start over
        </button>
        <ExecutiveBriefDisplay brief={brief} />
      </div>
    );
  }

  if (step === "conversation" && selectedEvent && currentQuestion) {
    const progress = ((questionIndex + 1) / selectedEvent.questions.length) * 100;

    return (
      <div className="animate-fade-in">
        <div className="mb-6">
          <button
            onClick={() => {
              if (questionIndex > 0) {
                setQuestionIndex(questionIndex - 1);
              } else {
                reset();
              }
            }}
            className="mb-4 text-sm text-muted-light transition-colors hover:text-foreground"
          >
            ← Back
          </button>

          <div className="mb-2 flex items-center justify-between text-xs text-muted-light">
            <span>{selectedEvent.title}</span>
            <span>
              {questionIndex + 1} / {selectedEvent.questions.length}
            </span>
          </div>
          <div className="h-0.5 overflow-hidden rounded-full bg-border-light">
            <div
              className="h-full rounded-full bg-crimson transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        <h2 className="mb-6 text-xl font-medium tracking-tight text-foreground md:text-2xl">
          {currentQuestion.question}
        </h2>

        {currentQuestion.type === "multiselect" ? (
          <div>
            <div className="mb-4 space-y-1.5">
              {currentQuestion.options?.map((option) => {
                const selected = (
                  (answers[currentQuestion.id] as string[]) ?? []
                ).includes(option);
                return (
                  <button
                    key={option}
                    onClick={() => handleMultiselectToggle(option)}
                    className={`w-full rounded-lg border px-4 py-3 text-left text-sm transition-all duration-150 ${
                      selected
                        ? "border-crimson/40 bg-crimson-light text-foreground"
                        : "border-border bg-surface text-muted hover:border-border hover:bg-border-light/60 hover:text-foreground"
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <span
                        className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${
                          selected
                            ? "border-crimson bg-crimson text-white"
                            : "border-border"
                        }`}
                      >
                        {selected && (
                          <svg className="h-3 w-3" fill="currentColor" viewBox="0 0 12 12">
                            <path d="M10.28 2.28a1 1 0 0 1 0 1.42l-5.5 5.5a1 1 0 0 1-1.42 0l-2.5-2.5a1 1 0 1 1 1.42-1.42L4.5 7.15l4.79-4.79a1 1 0 0 1 1.42 0z" />
                          </svg>
                        )}
                      </span>
                      {option}
                    </span>
                  </button>
                );
              })}
            </div>
            <CTAButton
              onClick={handleMultiselectContinue}
              className={
                ((answers[currentQuestion.id] as string[]) ?? []).length === 0
                  ? "pointer-events-none opacity-40"
                  : ""
              }
            >
              Continue
            </CTAButton>
          </div>
        ) : (
          <div className="space-y-1.5">
            {currentQuestion.options?.map((option) => (
              <button
                key={option}
                onClick={() => handleAnswer(option)}
                className="w-full rounded-lg border border-border bg-surface px-4 py-3 text-left text-sm text-foreground transition-all duration-150 hover:border-border hover:bg-border-light/60"
              >
                {option}
              </button>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className={isHome ? "w-full" : ""}>
      <h1
        className={`mb-6 text-center font-medium tracking-tight text-foreground ${
          isHome ? "text-2xl md:text-3xl" : "font-serif text-4xl md:text-5xl"
        }`}
      >
        What changed?
      </h1>

      {isHome ? (
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
          {events.map((event) => (
            <button
              key={event.slug}
              onClick={() => selectEvent(event)}
              className="group rounded-lg border border-border bg-surface px-3 py-3.5 text-left transition-all duration-150 hover:border-crimson/25 hover:bg-border-light/40 sm:px-4"
            >
              <span className="mb-1.5 block text-base text-muted-light transition-colors group-hover:text-crimson">
                {event.icon}
              </span>
              <span className="block text-[13px] font-medium leading-snug text-foreground sm:text-sm">
                {event.title}
              </span>
            </button>
          ))}
        </div>
      ) : (
        <>
          <p className="mx-auto mb-10 max-w-lg text-center text-[15px] leading-relaxed text-muted">
            Business change creates technology implications. Select the event
            driving your organization&apos;s technology conversation.
          </p>
          <div className="grid gap-3 sm:grid-cols-2">
            {events.map((event) => (
              <button
                key={event.slug}
                onClick={() => selectEvent(event)}
                className="group flex flex-col rounded-xl border border-border bg-surface p-5 text-left transition-all duration-200 hover:border-crimson/30 hover:bg-border-light/40"
              >
                <span className="mb-3 flex h-9 w-9 items-center justify-center rounded-lg bg-crimson-light text-base text-crimson transition-colors group-hover:bg-crimson group-hover:text-white">
                  {event.icon}
                </span>
                <span className="mb-1 text-[16px] font-semibold tracking-tight text-foreground">
                  {event.title}
                </span>
                <span className="text-sm leading-relaxed text-muted">
                  {event.shortDescription}
                </span>
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
